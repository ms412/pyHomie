#__name__ = "pyHomie"
__app__ = "pyHomnie"
__version__ = "0.0.2"
__date__= "2021/04/25"
__author__ = "Markus Schiesser"
__contact__ = "M.Schiesser@gmail.com"
__copyright__ = "Copyright (C) 2023 Markus Schiesser"
__license__ = 'THE BEER-WARE LICENSE'

